﻿/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'si', {
	anchor: 'ආධාරය',
	hiddenfield: 'සැඟවුණු ප්‍රදේශය',
	iframe: 'IFrame',
	unknown: 'Unknown Object' // MISSING
} );
