﻿/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'bidi', 'zh', {
	ltr: '文字方向從左至右',
	rtl: '文字方向從右至左'
} );
