﻿/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'bidi', 'vi', {
	ltr: 'Văn bản hướng từ trái sang phải',
	rtl: 'Văn bản hướng từ phải sang trái'
} );
