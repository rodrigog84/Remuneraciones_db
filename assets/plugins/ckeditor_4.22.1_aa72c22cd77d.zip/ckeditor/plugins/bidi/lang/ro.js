﻿/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'bidi', 'ro', {
	ltr: 'Direcția textului de la stânga la dreapta',
	rtl: 'Direcția textului de la dreapta la stânga'
} );
