﻿/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'bidi', 'cy', {
	ltr: 'Cyfeiriad testun o\'r chwith i\'r dde',
	rtl: 'Cyfeiriad testun o\'r dde i\'r chwith'
} );
