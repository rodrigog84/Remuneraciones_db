﻿/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'el', {
	label: 'Μορφές',
	panelTitle: 'Στυλ Μορφοποίησης',
	panelTitle1: 'Στυλ Τμημάτων',
	panelTitle2: 'Στυλ Εν Σειρά',
	panelTitle3: 'Στυλ Αντικειμένων'
} );
