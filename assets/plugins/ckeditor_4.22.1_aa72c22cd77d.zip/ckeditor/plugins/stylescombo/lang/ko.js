﻿/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'ko', {
	label: '스타일',
	panelTitle: '전체 구성 스타일',
	panelTitle1: '블록 스타일',
	panelTitle2: '인라인 스타일',
	panelTitle3: '객체 스타일'
} );
