﻿/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'fi', {
	label: 'Tyyli',
	panelTitle: 'Muotoilujen tyylit',
	panelTitle1: 'Lohkojen tyylit',
	panelTitle2: 'Rivinsisäiset tyylit',
	panelTitle3: 'Objektien tyylit'
} );
