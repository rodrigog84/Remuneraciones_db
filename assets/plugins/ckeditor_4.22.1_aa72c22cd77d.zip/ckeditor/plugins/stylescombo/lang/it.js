﻿/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'it', {
	label: 'Stili',
	panelTitle: 'Stili di formattazione',
	panelTitle1: 'Stili per blocchi',
	panelTitle2: 'Stili in linea',
	panelTitle3: 'Stili per oggetti'
} );
