﻿/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'bg', {
	label: 'Стилове',
	panelTitle: 'Стилове за форматиране',
	panelTitle1: 'Блокови стилове',
	panelTitle2: 'Поредови стилове',
	panelTitle3: 'Обектни стилове'
} );
