﻿/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'sq', {
	label: 'Stilet',
	panelTitle: 'Formatimi i Stileve',
	panelTitle1: 'Stilet e Bllokut',
	panelTitle2: 'Stilet e Brendshme',
	panelTitle3: 'Stilet e Objektit'
} );
