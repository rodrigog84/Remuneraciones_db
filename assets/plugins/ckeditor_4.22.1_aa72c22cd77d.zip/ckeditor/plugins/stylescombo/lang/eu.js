﻿/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'eu', {
	label: 'Estiloak',
	panelTitle: 'Formatu estiloak',
	panelTitle1: 'Bloke estiloak',
	panelTitle2: 'Lineako estiloak',
	panelTitle3: 'Objektu estiloak'
} );
