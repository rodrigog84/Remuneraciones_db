﻿/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'tt', {
	label: 'Стильләр',
	panelTitle: 'Форматлау стильләре',
	panelTitle1: 'Блоклар стильләре',
	panelTitle2: 'Эчке стильләр',
	panelTitle3: 'Объектлар стильләре'
} );
