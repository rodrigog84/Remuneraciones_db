﻿/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'km', {
	label: 'រចនាបថ',
	panelTitle: 'ទ្រង់ទ្រាយ​រចនាបថ',
	panelTitle1: 'រចនាបថ​ប្លក់',
	panelTitle2: 'រចនាបថ​ក្នុង​ជួរ',
	panelTitle3: 'រចនាបថ​វត្ថុ'
} );
