﻿/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'nb', {
	label: 'Stil',
	panelTitle: 'Stilformater',
	panelTitle1: 'Blokkstiler',
	panelTitle2: 'Inlinestiler',
	panelTitle3: 'Objektstiler'
} );
