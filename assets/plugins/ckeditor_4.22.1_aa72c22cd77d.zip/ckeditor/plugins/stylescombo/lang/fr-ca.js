﻿/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'fr-ca', {
	label: 'Styles',
	panelTitle: 'Styles de formattage',
	panelTitle1: 'Styles de block',
	panelTitle2: 'Styles en ligne',
	panelTitle3: 'Styles d\'objet'
} );
