﻿/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'de-ch', {
	label: 'Stil',
	panelTitle: 'Formatierungsstile',
	panelTitle1: 'Blockstile',
	panelTitle2: 'Inline Stilart',
	panelTitle3: 'Objektstile'
} );
